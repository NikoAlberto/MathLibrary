#pragma once
#include<vector>
#include<random>
#include <initializer_list> 
#include <cassert>  
#include"Exception.h"
using namespace std;
class Matrix
{
protected:
	int M;
	int N;
	vector<vector<double>> matrix;
public:
	
	Matrix() {
		this->M = 1;
		this->N = 1;
		matrix = { { 1 } };
		matrix.resize(1);
	
	}
	
	Matrix(int m, int n)
	{
		this->M = m;
		this->N = n;
		matrix.resize(M);
		for (int i = 0; i < M; i ++)
		         matrix[i].resize(N);
			
	}

	Matrix(int m, int n, vector<double> mat) {
		this->M = m;
		this->N = n;

		if (M * N != mat.size())
			throw MyException1();
		matrix.resize(M);
		for (int i = 0; i < mat.size(); i+=N)
		{
			     matrix[i/N].resize(N);
			for (int j = 0; j < N; j++)
			{
				this->matrix[i/N][j] = mat[j+i];
			}
		}
	}

	Matrix(initializer_list<double> list) {
		this->N = list.size();
		this->M = list.size();
		vector<double> x;
		for (auto m : list)
			x.push_back(m);
		for (int i = 0; i < list.size(); i++)
			this->matrix.push_back(x);
	}


	int get_Mrows() { return M; }
	int get_Ncols() { return N; }
	void set_elm(size_t i, size_t j, double a) { this->matrix[i][j] = a; }
	vector<vector<double>>& get_matrix(){return  matrix; }
	//overload
	friend ostream& operator<<(ostream& cout, Matrix& object);
	friend Matrix operator+(Matrix& object1, Matrix& object2);
	friend Matrix operator-(Matrix& object1, Matrix& object2);
	friend Matrix operator*(Matrix& object1, Matrix& object2);
	

	
	Matrix& operator*(double num);
	friend Matrix& operator*(double num, Matrix& object);

	//METHODs
	//Adamara multiplication
	Matrix& Adamara(Matrix& object1);
	//Transpose
	Matrix& Transpose();
	//save
	void save_file(string bins);
	//load
	void load_file(string bins);
	//init
	//Matrix& Matrix(initializer_list<double> list);

	//FRIEND-FUNCTIONS
	friend void swaprows(Matrix& object, size_t row1, size_t row2);
	friend Matrix& RowReduce(Matrix& object, vector<double>& bearing_vec);
	friend void rowDivision(Matrix& object, size_t row1, double b_el);
	friend void SumRow(Matrix& object, size_t row1, size_t row2, double k);
	friend double scalar_product(Matrix& object1, Matrix& object2);
	friend double trace(Matrix& object);
	friend double vector_module(Matrix& object);
	friend double vector_norm_max(Matrix& object);
	friend double matrix_module(Matrix& object);
	friend double Det(Matrix& object);
	friend Matrix& RowReduce(Matrix& object);
	friend int Rank(Matrix& object);
	friend Matrix& matrix_norm(Matrix& object);
	friend Matrix& vector_norm(Matrix& object);
	friend Matrix& inverse_matrix(Matrix& object);
	friend double Mean(Matrix& object, int num);
	friend double Norm_RCA(Matrix& object, int row);
	friend Matrix new_matrix_RCA(Matrix& object);
	friend vector<double> extract_col(Matrix& object, int col);
	friend Matrix& insert_col(Matrix& object1, Matrix& vec);

	friend Matrix& ReadTextFile(Matrix& object, string filet);//
	friend ofstream& operator<<(string filet, Matrix& object);

	friend void CreateBinary(Matrix& object, string bins);
	friend Matrix& ReadBinaryFile(Matrix& object, string bins);
};

#include "Overloaded.h"

#include "Semi-class.h"